<?php 
    $conn = mysqli_connect("localhost", "root", "", "db_kotapurwokerto");
    if (mysqli_connect_error()) {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
