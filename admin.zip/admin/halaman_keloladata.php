<?php 
include "validasi_session.php";
include "koneksi.php";

// KECAMATAN UNTUK SELECT OPTION
$sqlKecamatan = "SELECT * FROM kecamatan ORDER BY nama_kecamatan ASC";
$listKecamatan = mysqli_query($conn, $sqlKecamatan);


// KELURAHAN DARI JAVASCRIPT AJAX
if (isset($_GET['id_kecamatan'])) {
  if ($_GET['id_kecamatan'] != 0) {
    $result =[];

    $sqlKelurahan = "SELECT * FROM kelurahan WHERE id_kecamatan=".$_GET['id_kecamatan']." ORDER BY nama_kelurahan ASC";
    $listKelurahan = mysqli_query($conn, $sqlKelurahan);
    $rowKelurahan = [];
    while ($row = mysqli_fetch_assoc($listKelurahan)) {
      $temp = [];
      $temp['id_kelurahan'] = $row['id_kelurahan'];
      $temp['id_kecamatan'] = $row['id_kecamatan'];
      $temp['nama_kelurahan'] = $row['nama_kelurahan'];
      $rowKelurahan = $temp;
    }
    $result['kelurahan'] = $rowKelurahan;

    $sqlPoligon = "SELECT * FROM poligon WHERE id_kecamatan=" .$temp['id_kecamatan'];
    $listPoligon = mysqli_query($conn, $sqlPoligon);
    $rowPoligon = [];
    while ($row = mysqli_fetch_assoc($listPoligon)) {
      $rowPoligon[] = [$row['lat'], $row['lng']];
    }
    $result['poligon'] = $rowPoligon;

    echo json_encode($rowKelurahan);
    exit;
  }
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
    

    <!-- Bootstrap Icon -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.2/font/bootstrap-icons.css" />
  
    <!-- Mapbox -->
    <script src="https://api.mapbox.com/mapbox-gl-js/v2.8.2/mapbox-gl.js"></script>
    <link href="https://api.mapbox.com/mapbox-gl-js/v2.8.2/mapbox-gl.css" rel="stylesheet" />

    <!-- My Style -->
    <link rel="stylesheet" href="css/style.css" />

    <!-- logo -->
    <link rel="shortcut icon" href="../logo.png">

    <title>Kelola Data | SIG</title>
  </head>
  <body>
    <section id="navbar">
      <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #A0522D">
        <div class="container">
          <a class="navbar-brand" href="dashboard.php" style="color: #F5F5DC">
            <strong>SIG  <span style="color: #F5F5DC">WISATA INDUSTRI KOTA PURWOKERTO</span></strong>
          </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <i class="bi bi-gear-fill"></i>
          </button>
          <div class="collapse navbar-collapse justify-content-end" id="navbarTogglerDemo02">
            <ul class="navbar-nav mb-2 mb-lg-0">
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="color: #F5F5DC"> <strong>More</strong> </a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                  <li><a class="dropdown-item" href="dashboard.php">Dashboard</a></li>
                  <li><a class="dropdown-item" href="session_logout.php">Logout</a></li>
                </ul>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <hr style="margin: 0px 0px; height: 1px; opacity: 0.5" />
    </section>

    <section id="table-data">
      <div class="table-data">
        <div class="container">
          <div class="card shadow">
            <div class="card-header py-3">
              <h4 class="text-center">Kelola Data</h4>
              <div class="d-flex justify-content-end">
                <a href="tambah-data.php" class="btn btn-block text-light" style="background-color: #A0522D;"><i class="bi bi-plus-lg"></i> Tambah Data</a>
              </div>
            </div>

            
            <div class="card-body">
             <!-- Tambahkan formulir untuk "Show entries" -->
              <div class="d-flex justify-content-between align-items-center mb-2">
                <div class="form-inline">
                  <label class="mr-2">Show entries:</label>
                    <select class="form-control" id="entriesSelect">
                      <option value="10">10</option>
                      <option value="25">25</option>
                      <option value="50">50</option>
                      <option value="100">100</option>
                    </select>
                </div>
              <div class="form-inline mb-2">
                <label class="mr-2">Search:</label>
                <input type="text" class="form-control" id="searchInput" placeholder="Type to search">
              </div>
            </div>
          </div>

            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr style="text-align: center;">
                      <th style="width: 20px;">No</th>
                      <th style="width: 60px;">Nama</th>
                      <th style="width: 60px;">Alamat</th>
                      <th style="width: 20px;">Kategori</th>
                      <th style="width: 20px;">Kecamatan</th>
                      <th style="width: 20px;">Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                      <?php 
                      $data = "SELECT l.id_lokasi, l.nama, l.alamat, l.kategori, k.nama_kecamatan
                        FROM lokasi l, kecamatan k WHERE l.id_kecamatan = k.id_kecamatan";
                      $query = mysqli_query($conn, $data);
                      $nomor = 1; // Tambahkan variabel nomor urut
                      while ($row = mysqli_fetch_assoc($query)) {
                        $id = $row['id_lokasi'];
                        $nama = $row['nama'];
                        $alamat = $row['alamat'];
                        $kategori = $row['kategori'];
                        $kecamatan = $row['nama_kecamatan'];

                        echo "
                        <tr  style='text-align: center;'>
                        <td>$nomor</td>
                        <td>$nama</td>
                        <td>$alamat</td>
                        <td>$kategori</td>
                        <td>$kecamatan</td>
                        <td><a class='btn btn-warning' href='edit-data.php?id=$id'>Ubah</a> <a class='btn btn-danger' href='#' onClick='confirm_modal(\"proses.php?p=hapus_lokasi&&id=$id\")'>Hapus</a></td>
                        </tr>";

                        $nomor++; // Increment nomor urut
                      }
                      
                      
                      ?>
                  </tbody>
                  <!-- <td><a class='btn btn-warning' href='edit-data.php?id=$id'>Ubah</a> <a class='btn btn-danger' href='proses.php?p=hapus_lokasi&&id=$id'>Hapus</a></td> -->
                </table>
              </div>
              <div class="d-flex justify-content-end mt-3">
                <button class="btn btn-light" id="prevPage">
                  <i class="bi bi-arrow-left"></i> </button>
                <button class="btn btn-light ml-2" id="nextPage">
                  <i class="bi bi-arrow-right"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Modal Popup untuk delete -->
      <div class="modal fade" id="modal_delete">
        <div class="modal-dialog">
          <div class="modal-content" style="margin-top:30vh;">
            <div class="modal-header">
                <h6 class="modal-title" style="text-align: center;">Anda yakin akan menghapus data ini...?</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-footer" style="margin: 0px; border-top: 0px; text-align: center;">
                <a href="#" class="btn btn-danger btn-sm" id="delete_link">Hapus</a>
                <button type="button" class="btn btn-success btn-sm" data-bs-dismiss="modal">Batal</button>
            </div>
          </div>
        </div>
      </div>
    </section>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.12.0/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/select/1.4.0/js/dataTables.select.min.js"></script>

    <!-- js untuk popup modal delete -->
    <script type="text/javascript">
      function confirm_modal(delete_url){
        $('#modal_delete').modal('show', {backdrop: 'static'});
        document.getElementById('delete_link').setAttribute('href', delete_url);
      }
    </script>

<script>
  // Fungsi pencarian
  $(document).ready(function () {
    $("#searchInput").on("keyup", function () {
      var value = $(this).val().toLowerCase();
      $("#dataTable tbody tr").filter(function () {
        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
      });
    });
  });
</script>


    <script>
      mapboxgl.accessToken = "pk.eyJ1IjoibWFyc2VsYWRlcmFoYXJqbyIsImEiOiJjbDV4cHBzZzEwdzA4M2ttcHc2bnhpMnM2In0.rqkuPeTWmIIRjq9ADpJoCw";
      var map = new mapboxgl.Map({
        container: "map", // container ID
        style: "mapbox://styles/mapbox/streets-v11", // style URL
        center: [109.23819945612114, -7.419380317240572], // starting position [lng, lat]
        zoom: 10, // starting zoom
      });

      <script>
  $(document).ready(function () {
    var dataTable = $('#dataTable').DataTable({
      // Konfigurasi DataTables lainnya disini
    });

    // Fungsi untuk menangani perubahan jumlah entri yang ditampilkan
    $("#entriesSelect").change(function () {
      var selectedValue = $(this).val();
      dataTable.page.len(selectedValue).draw();
    });

    // Fungsi untuk menangani klik tombol Selanjutnya
    $('#nextPage').on('click', function () {
      dataTable.page('next').draw('page');
    });

    // Fungsi untuk menangani klik tombol Kembali
    $('#prevPage').on('click', function () {
      dataTable.page('previous').draw('page');
    });
  });
</script>
    </script>
  </body>
</html>
